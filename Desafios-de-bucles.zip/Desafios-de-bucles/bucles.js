// 1. Imprimir impares 1-20

for (var U = 1; U < 20; U+=2){
        console.log(U);
}

// 2. Disminuir múltiplos de 3

for(var U = 100; U >- 1; U--){
    if(U % 3 == 0){
        console.log(U);
    }
}

// 3. Imprimir la secuencia

for(var U = 4; U >- 4; U = U -1.5){
    console.log(U);
}

// 4. Sigma

var suma = 0;
for(var U = 1; U <= 100; U ++){
    suma += U;
    console.log(sum)
}

// 5. Factorial

var multi = 1;
for(var U = 1; U <= 12; U++){
    multi *= U;
    console.log(multi)
}
